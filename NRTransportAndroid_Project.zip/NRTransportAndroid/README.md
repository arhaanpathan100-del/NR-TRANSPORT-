# NR TRANSPORT Android project

This is an Android Studio project that packages the supplied HTML bilty prototype inside a native Android WebView app.

## Build an APK
1. Install Android Studio (current stable) on a computer.
2. Open Android Studio and choose **Open**, then select this `NRTransportAndroid` folder.
3. Allow Gradle sync and install the Android SDK platform requested by the project (compile SDK 35).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. When finished, choose **locate** in the build notification. The debug APK is normally at:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer that APK to the father's Android phone and install it. Android may ask permission to install apps from that source.

## Prototype login
`NR@2026`

## Important limitations
- The current prototype stores records in local browser/WebView storage on this phone only. It does not sync to a cloud database and does not back up automatically.
- The sample password is visible in the HTML and is not suitable for production security. Replace it with a secure authentication approach before real business use.
- Test printing/PDF generation on the target phone. WebView print behaviour may require additional native print integration.
- Confirm the printed bilty, GSTIN, bank details and all company details before using it for actual consignments.
- This project source is prepared for Android Studio; an APK has not been built or device-tested in this environment.


## Build from an Android phone using GitHub Actions
A workflow is included at `.github/workflows/build-apk.yml`.
1. Create a GitHub account and a new repository.
2. Upload the *contents* of this project ZIP to the repository (including the hidden `.github` folder; if using GitHub mobile web, enable desktop site if needed).
3. Open the repository's **Actions** tab and select **Build NR TRANSPORT APK**.
4. Tap **Run workflow**. Wait for the run to finish successfully.
5. Open the completed run, find **Artifacts**, and download `NR-TRANSPORT-debug-APK`. Extract the downloaded artifact ZIP to get `app-debug.apk`.

This uses GitHub-hosted build runners. You must sign in and upload the source project yourself; the APK is not created until the workflow completes successfully.
